
public class string {
	public static void main(String args[]){  
		String s1="JAVA is Simple";  
		String s1upper=s1.toUpperCase();  
		System.out.println(s1upper); 
		String s1lower=s1.toLowerCase();
		System.out.println(s1lower);
		char ch=s1.charAt(0);
		for(String w:s1.split("\\s",0))
		{
			System.out.println(w);
		}
		StringBuilder sb=new StringBuilder("java is simple");  
		sb.reverse();  
		System.out.println(sb);
		System.out.println("string length is: "+s1.length());
		}  
}

