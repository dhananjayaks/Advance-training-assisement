import java.util.StringTokenizer;

public class split {
	public static void main(String[] args) {
	// TODO Auto-generated method stub

    StringTokenizer st1 = new StringTokenizer("23  +      45   - (   343   /   12  )", " ");
    

    while (st1.hasMoreTokens()) 
    System.out.println(st1.nextToken());
}

}
