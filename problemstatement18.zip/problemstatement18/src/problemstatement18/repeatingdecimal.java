package problemstatement18;

import java.util.HashMap;

public class repeatingdecimal {
	 static String fractionToDecimal(int numr, int denr)
	    {
	        // Initialize result
	        String res = "";
	 
	         
	        HashMap<Integer, Integer> mp = new HashMap<>();
	        mp.clear();
	 
	        // Find first remainder
	        int rem = numr % denr;
	 
	        // Keep finding remainder until
	        //  either remainder becomes 0 or repeats
	        while ((rem != 0) && (!mp.containsKey(rem)))
	        {
	            // Store this remainder
	            mp.put(rem, res.length());
	 
	            // Multiply remainder with 10
	            rem = rem * 10;
	 
	            // Append rem / denr to result
	            int res_part = rem / denr;
	            res += String.valueOf(res_part);
	 
	            // Update remainder
	            rem = rem % denr;
	        }
	 
	        if (rem == 0)
	            return "";
	        else if (mp.containsKey(rem))
	            return res.substring(mp.get(rem));
	 
	        return "";
	    }
	 
	    // Driver code
	    public static void main(String[] args)
	    {
	        int numr1 = 1, denr1 = 3;
	        
	        String res = fractionToDecimal(numr1, denr1);
	        
	        if (res == "")
	            System.out.print("No Repeating decimal");
	        else
	            System.out.print("Repeating decimal is "
	                             + res);
	        int numr2= 1,denr2=4;
	        String ret = fractionToDecimal(numr2, denr2);
	        if (res == "")
	            System.out.print("No Repeating decimal" +ret);
	        else
	            System.out.print("Repeating decimal is "+ret);
	    }
	}