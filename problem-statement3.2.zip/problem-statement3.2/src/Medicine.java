
public class Medicine {
	String date;
	int P;
	public void getDetails(int P,String date){
		System.out.println("Price");
		System.out.println("Expiry date");}
	public void displayLabel(){
		System.out.println("Company : tom Pharma");
		System.out.println("Address : kgf");}
	 
	}
class Tablet extends Medicine{
	public void displayLabel(){
		System.out.println("store in a cool dry place");
		}}
class Syrup extends Medicine{
	public void displayLabel()
	{
		System.out.println("Consumption as directed by thephysician");
		}}
class Ointment extends Medicine{
	public void displayLabel(){
		System.out.println("for external use only");
		}
	}
 

 
