import java.util.Vector;

public class EmployeeCollection {
public static void main(String arg[])
{
	Vector<Employee>v=addInput();
	display(v);
	
}
 
public static Vector<Employee> addInput()
{
	Employee e1=new Employee(104,"tom","srilanka");
	Employee e2=new Employee(104,"jerry","dubai");
	Employee e3=new Employee(108,"bheem","jammica");
	Vector<Employee> v=new Vector<Employee>();
	v.add(e1);
	v.add(e2);
	v.add(e3);
	return v;
}
private static void display(Vector<Employee> v) {
	for(Employee e:v)
	{
	System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
	// TODO Auto-generated method stub
	
}
}
}
