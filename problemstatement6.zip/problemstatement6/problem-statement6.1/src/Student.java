import java.util.ArrayList;

public class Student {
	public static void main(String args[]){  
	      ArrayList<String> alist=new ArrayList<String>();  
	      alist.add("tom");
	      alist.add("jeery");
	      alist.add("bheem");
	      alist.add("kalaki");
	      alist.add("dora");
	      alist.add("frg");
	  
	      //displaying elements
	      System.out.println(alist);
	  
	      //Adding "Steve" at the fourth position
	      alist.add(3, "MSD");
	  
	      //displaying elements
	      System.out.println(alist);
	   }  
}
